
import React from 'react';
import { Flashcard } from '../types';
import DownloadIcon from './icons/DownloadIcon';

interface FlashcardDeckProps {
  flashcards: Flashcard[];
}

const FlashcardDeck: React.FC<FlashcardDeckProps> = ({ flashcards }) => {
  const exportToCsv = () => {
    if (flashcards.length === 0) return;
    const headers = "Word,Definition\n";
    const rows = flashcards.map(fc => `"${fc.word.replace(/"/g, '""')}","${fc.definition.replace(/"/g, '""')}"`).join('\n');
    const csvContent = "data:text/csv;charset=utf-8," + encodeURIComponent(headers + rows);
    const link = document.createElement("a");
    link.setAttribute("href", csvContent);
    link.setAttribute("download", "readly_flashcards.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="bg-cardBg p-6 rounded-2xl shadow-lg mt-8">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-bold text-secondaryText">Flashcards ({flashcards.length})</h2>
        <button
          onClick={exportToCsv}
          disabled={flashcards.length === 0}
          className="flex items-center gap-2 bg-primaryRed/20 text-primaryRed font-semibold py-2 px-4 rounded-lg hover:bg-primaryRed/30 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <DownloadIcon className="w-5 h-5" />
          Export
        </button>
      </div>
      {flashcards.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-1 xl:grid-cols-2 gap-4 max-h-60 overflow-y-auto pr-2">
          {flashcards.map((card, index) => (
            <div key={index} className="bg-darkBg p-4 rounded-xl">
              <p className="font-bold text-accentRed">{card.word}</p>
              <p className="text-secondaryText/80 mt-1 text-sm">{card.definition}</p>
            </div>
          ))}
        </div>
      ) : (
        <p className="text-secondaryText/60 text-center py-8">Add words from the text to create flashcards.</p>
      )}
    </div>
  );
};

export default FlashcardDeck;
