
import React from 'react';
import { HistoryItem, Flashcard } from '../types';

interface DashboardProps {
  history: HistoryItem[];
  flashcards: Flashcard[];
  onSelectHistoryItem: (text: string) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ history, flashcards, onSelectHistoryItem }) => {
  return (
    <div className="container mx-auto p-4 md:p-8 animate-fade-in-up">
      <h1 className="text-4xl font-extrabold text-secondaryText mb-8">Your Progress</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
        <div className="bg-cardBg p-6 rounded-2xl shadow-lg text-center">
          <p className="text-5xl font-bold text-primaryRed">{history.length}</p>
          <p className="text-secondaryText/70 mt-2">Texts Analyzed</p>
        </div>
        <div className="bg-cardBg p-6 rounded-2xl shadow-lg text-center">
          <p className="text-5xl font-bold text-primaryRed">{flashcards.length}</p>
          <p className="text-secondaryText/70 mt-2">Words in Flashcards</p>
        </div>
      </div>

      <div>
        <h2 className="text-2xl font-bold text-secondaryText mb-6">Recent Texts</h2>
        {history.length > 0 ? (
          <div className="space-y-4">
            {history.slice(0, 10).map((item) => (
              <div
                key={item.id}
                onClick={() => onSelectHistoryItem(item.text)}
                className="bg-cardBg p-4 rounded-xl shadow-md cursor-pointer hover:bg-cardBg/70 transition-colors"
              >
                <p className="text-secondaryText/90 truncate">{item.text}</p>
                <p className="text-xs text-secondaryText/50 mt-2">
                  {new Date(item.timestamp).toLocaleString()}
                </p>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-12 bg-cardBg rounded-2xl">
            <p className="text-secondaryText/60">
              Your analyzed texts will appear here.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Dashboard;
