import React, { useState, useRef, useEffect, useMemo } from 'react';
import { AnalyzedWord, Flashcard } from '../types';
import PlusIcon from './icons/PlusIcon';
import SpeakerIcon from './icons/SpeakerIcon';
import StopIcon from './icons/StopIcon';
import SummarizeIcon from './icons/SummarizeIcon';


interface AnalyzedTextProps {
  words: AnalyzedWord[];
  onAddToFlashcards: (flashcard: Flashcard) => void;
  onSummarize: () => void;
}

const AnalyzedText: React.FC<AnalyzedTextProps> = ({ words, onAddToFlashcards, onSummarize }) => {
  const [activeWord, setActiveWord] = useState<{ index: number; rect: DOMRect } | null>(null);
  const wordRefs = useRef<(HTMLSpanElement | null)[]>([]);

  const [isSpeaking, setIsSpeaking] = useState(false);
  const [speakingWordIndex, setSpeakingWordIndex] = useState<number | null>(null);

  const charIndexToWordIndexMap = useMemo(() => {
    const map: { charIndex: number, wordIndex: number }[] = [];
    let currentCharIndex = 0;
    words.forEach((word, index) => {
        map.push({ charIndex: currentCharIndex, wordIndex: index });
        currentCharIndex += word.text.length;
    });
    return map;
  }, [words]);

  const handleToggleSpeak = () => {
    if (isSpeaking) {
        speechSynthesis.cancel();
        setIsSpeaking(false);
        setSpeakingWordIndex(null);
    } else {
        const fullText = words.map(w => w.text).join('');
        const utterance = new SpeechSynthesisUtterance(fullText);

        utterance.onstart = () => setIsSpeaking(true);
        utterance.onend = () => {
            setIsSpeaking(false);
            setSpeakingWordIndex(null);
        };
        utterance.onerror = () => {
             setIsSpeaking(false);
             setSpeakingWordIndex(null);
        };
        utterance.onboundary = (event) => {
            let wordIndex = -1;
            for (let i = charIndexToWordIndexMap.length - 1; i >= 0; i--) {
                if (event.charIndex >= charIndexToWordIndexMap[i].charIndex) {
                    wordIndex = charIndexToWordIndexMap[i].wordIndex;
                    break;
                }
            }
            setSpeakingWordIndex(wordIndex);
        };

        speechSynthesis.speak(utterance);
    }
  };

  useEffect(() => {
    const handleOutsideClick = (event: MouseEvent) => {
      if (activeWord && !wordRefs.current[activeWord.index]?.contains(event.target as Node)) {
        const popup = document.getElementById('definition-popup');
        if (popup && !popup.contains(event.target as Node)) {
          setActiveWord(null);
        }
      }
    };
    document.addEventListener('mousedown', handleOutsideClick);
    
    // Cleanup speech synthesis on component unmount
    return () => {
      document.removeEventListener('mousedown', handleOutsideClick);
      if (speechSynthesis.speaking) {
          speechSynthesis.cancel();
      }
    };
  }, [activeWord]);


  const handleWordClick = (index: number) => {
    const word = words[index];
    const ref = wordRefs.current[index];
    if (word.isDifficult && ref) {
      setActiveWord({ index, rect: ref.getBoundingClientRect() });
    }
  };
  
  const currentDifficultWord = activeWord !== null ? words[activeWord.index] : null;

  return (
    <div className="bg-cardBg p-8 rounded-2xl shadow-lg relative">
        <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold text-secondaryText">Analyzed Text</h2>
            <div className="flex items-center gap-2">
                <button
                    onClick={onSummarize}
                    className="flex items-center gap-2 bg-darkBg border border-primaryRed/30 text-primaryRed font-semibold py-2 px-4 rounded-lg hover:bg-primaryRed/20 transition-colors"
                    aria-label="Summarize text"
                >
                    <SummarizeIcon className="w-5 h-5" />
                    <span>Summarize</span>
                </button>
                <button
                    onClick={handleToggleSpeak}
                    className="flex items-center gap-2 bg-darkBg border border-primaryRed/30 text-primaryRed font-semibold py-2 px-4 rounded-lg hover:bg-primaryRed/20 transition-colors"
                    aria-label={isSpeaking ? "Stop reading text" : "Read text aloud"}
                >
                    {isSpeaking ? <StopIcon className="w-5 h-5" /> : <SpeakerIcon className="w-5 h-5" />}
                    <span>{isSpeaking ? 'Stop' : 'Speak'}</span>
                </button>
            </div>
        </div>
      <p className="text-secondaryText/90 text-lg leading-loose font-medium">
        {words.map((word, index) => (
          <span
            key={index}
            ref={(el) => { wordRefs.current[index] = el; }}
            onClick={() => handleWordClick(index)}
            className={
              (word.isDifficult
                ? 'text-accentRed underline decoration-accentRed/50 decoration-dotted cursor-pointer transition-colors hover:bg-accentRed/10 rounded-md px-1 py-0.5 '
                : '') +
              (speakingWordIndex === index
                ? 'bg-primaryRed/40 rounded-md'
                : '')
            }
          >
            {word.text}
          </span>
        ))}
      </p>

      {activeWord && currentDifficultWord?.isDifficult && (
        <div
          id="definition-popup"
          style={{
            top: activeWord.rect.bottom + window.scrollY + 8,
            left: activeWord.rect.left + window.scrollX,
          }}
          className="fixed bg-darkBg border border-primaryRed/50 rounded-xl shadow-2xl p-4 z-30 max-w-sm animate-fade-in-up"
        >
          <p className="font-bold text-lg text-accentRed">{currentDifficultWord.text}</p>
          <p className="text-secondaryText/90 mt-1">{currentDifficultWord.definition}</p>
          <button 
            onClick={() => {
              onAddToFlashcards({ word: currentDifficultWord.text, definition: currentDifficultWord.definition! });
              setActiveWord(null);
            }}
            className="mt-4 w-full flex items-center justify-center gap-2 bg-primaryRed/20 text-primaryRed font-semibold py-2 px-4 rounded-lg hover:bg-primaryRed/30 transition-colors">
            <PlusIcon className="w-5 h-5" />
            Add to Flashcards
          </button>
        </div>
      )}
    </div>
  );
};

export default AnalyzedText;
