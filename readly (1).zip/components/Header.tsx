
import React from 'react';
import BookOpenIcon from './icons/BookOpenIcon';
import UserIcon from './icons/UserIcon';
import HistoryIcon from './icons/HistoryIcon';

interface HeaderProps {
  onNavigateHome: () => void;
  onNavigateToDashboard: () => void;
}

const Header: React.FC<HeaderProps> = ({ onNavigateHome, onNavigateToDashboard }) => {
  return (
    <header className="bg-darkBg border-b border-cardBg/50 p-4 sticky top-0 z-20">
      <div className="container mx-auto flex justify-between items-center">
        <div
          onClick={onNavigateHome}
          className="flex items-center gap-2 cursor-pointer"
          aria-label="Go to home"
        >
          <BookOpenIcon className="w-8 h-8 text-primaryRed" />
          <h1 className="text-2xl font-bold text-secondaryText">Readly</h1>
        </div>
        <div className="flex items-center gap-4">
          <button
            onClick={onNavigateToDashboard}
            className="w-10 h-10 bg-cardBg rounded-full flex items-center justify-center hover:bg-cardBg/70 transition-colors"
            aria-label="View progress and history"
          >
            <HistoryIcon className="w-6 h-6 text-secondaryText/70" />
          </button>
          <div className="w-10 h-10 bg-cardBg rounded-full flex items-center justify-center">
            <UserIcon className="w-6 h-6 text-secondaryText/70" />
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
