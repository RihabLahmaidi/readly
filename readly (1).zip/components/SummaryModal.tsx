import React from 'react';
import XIcon from './icons/XIcon';

interface SummaryModalProps {
  summary: string;
  isLoading: boolean;
  onClose: () => void;
}

const SummaryModal: React.FC<SummaryModalProps> = ({ summary, isLoading, onClose }) => {
  return (
    <div
      className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 flex items-center justify-center p-4 animate-fade-in"
      onClick={onClose}
    >
      <div
        className="bg-cardBg w-full max-w-2xl rounded-2xl shadow-2xl border border-primaryRed/20 relative p-8"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-secondaryText/50 hover:text-secondaryText transition-colors"
          aria-label="Close summary"
        >
          <XIcon className="w-6 h-6" />
        </button>
        <h2 className="text-2xl font-bold text-secondaryText mb-6">Summary</h2>
        {isLoading ? (
          <div className="flex items-center justify-center h-48">
            <div className="w-12 h-12 border-4 border-accentRed border-t-transparent rounded-full animate-spin"></div>
          </div>
        ) : (
          <div className="text-secondaryText/90 text-lg leading-relaxed max-h-[60vh] overflow-y-auto pr-4">
            <p className="whitespace-pre-wrap">{summary}</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default SummaryModal;
