
export interface DifficultWord {
  word: string;
  definition: string;
}

export interface AnalyzedWord {
  text: string;
  isDifficult: boolean;
  definition?: string;
}

export interface ChatMessage {
  role: 'user' | 'model';
  content: string;
}

export interface Flashcard {
  word: string;
  definition: string;
}

export interface HistoryItem {
  id: string;
  text: string;
  timestamp: number;
}
