import React, { useState, useCallback, useEffect } from 'react';
import Header from './components/Header';
import AnalyzedText from './components/AnalyzedText';
import AiChat from './components/AiChat';
import FlashcardDeck from './components/FlashcardDeck';
import { analyzeTextForDifficultWords, startChat, streamChatResponse, summarizeText } from './services/geminiService';
import { DifficultWord, AnalyzedWord, ChatMessage, Flashcard, HistoryItem } from './types';
import BookOpenIcon from './components/icons/BookOpenIcon';
import Dashboard from './components/Dashboard';
import SummaryModal from './components/SummaryModal';

type AppState = 'initial' | 'loading' | 'analyzed' | 'error';
type AppView = 'main' | 'dashboard';

const App: React.FC = () => {
  const [appState, setAppState] = useState<AppState>('initial');
  const [view, setView] = useState<AppView>('main');
  const [inputText, setInputText] = useState<string>('');
  const [originalText, setOriginalText] = useState<string>('');
  const [analyzedWords, setAnalyzedWords] = useState<AnalyzedWord[]>([]);
  const [chatHistory, setChatHistory] = useState<ChatMessage[]>([]);
  const [flashcards, setFlashcards] = useState<Flashcard[]>([]);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [error, setError] = useState<string>('');
  const [isStreaming, setIsStreaming] = useState<boolean>(false);

  const [showSummaryModal, setShowSummaryModal] = useState<boolean>(false);
  const [summaryText, setSummaryText] = useState<string>('');
  const [isSummarizing, setIsSummarizing] = useState<boolean>(false);

  useEffect(() => {
    try {
      const storedFlashcards = localStorage.getItem('readlyFlashcards');
      if (storedFlashcards) setFlashcards(JSON.parse(storedFlashcards));
      const storedHistory = localStorage.getItem('readlyHistory');
      if (storedHistory) setHistory(JSON.parse(storedHistory));
    } catch (e) {
      console.error("Failed to load data from localStorage", e);
    }
  }, []);

  const saveFlashcards = (updatedFlashcards: Flashcard[]) => {
    try {
      localStorage.setItem('readlyFlashcards', JSON.stringify(updatedFlashcards));
    } catch (e) {
      console.error("Failed to save flashcards", e);
    }
  };

  const saveHistory = (updatedHistory: HistoryItem[]) => {
    try {
      localStorage.setItem('readlyHistory', JSON.stringify(updatedHistory));
    } catch (e) {
      console.error("Failed to save history", e);
    }
  };

  const handleAnalyzeText = useCallback(async () => {
    if (!inputText.trim()) return;
    setAppState('loading');
    setError('');
    try {
      const difficultWords: DifficultWord[] = await analyzeTextForDifficultWords(inputText);
      const difficultWordMap = new Map(difficultWords.map(dw => [dw.word.toLowerCase(), dw.definition]));
      
      const words = inputText.split(/(\s+|\n+)/);

      const newAnalyzedWords: AnalyzedWord[] = words.map(word => {
        const punctuationRegex = /[.,!?;:]$/;
        const cleanWord = word.replace(punctuationRegex, '').toLowerCase();
        const definition = difficultWordMap.get(cleanWord);
        return {
          text: word,
          isDifficult: !!definition,
          definition: definition,
        };
      });

      setAnalyzedWords(newAnalyzedWords);
      setOriginalText(inputText);
      startChat(inputText);
      setChatHistory([{ role: 'model', content: "Hello! Feel free to ask me anything about the text."}]);
      setAppState('analyzed');

      const newHistoryItem: HistoryItem = { id: new Date().toISOString(), text: inputText, timestamp: Date.now() };
      const updatedHistory = [newHistoryItem, ...history].slice(0, 50);
      setHistory(updatedHistory);
      saveHistory(updatedHistory);
    } catch (err) {
      console.error(err);
      setError('An error occurred while analyzing the text. Please check your API key and try again.');
      setAppState('error');
    }
  }, [inputText, history]);

  const handleSendMessage = useCallback(async (message: string) => {
    const newHistory: ChatMessage[] = [...chatHistory, { role: 'user', content: message }];
    setChatHistory(newHistory);
    setIsStreaming(true);

    try {
      let fullResponse = '';
      const responseGenerator = streamChatResponse(message);
      for await (const chunk of responseGenerator) {
        fullResponse += chunk;
        setChatHistory([...newHistory, { role: 'model', content: fullResponse }]);
      }
    } catch (err) {
        console.error(err);
        setChatHistory([...newHistory, {role: 'model', content: "Sorry, I encountered an error."}])
    } finally {
        setIsStreaming(false);
    }
  }, [chatHistory]);

  const handleAddFlashcard = useCallback((flashcard: Flashcard) => {
    if (!flashcards.some(fc => fc.word === flashcard.word)) {
      const updatedFlashcards = [...flashcards, flashcard];
      setFlashcards(updatedFlashcards);
      saveFlashcards(updatedFlashcards);
    }
  }, [flashcards]);

  const handleSummarize = async () => {
    setShowSummaryModal(true);
    setIsSummarizing(true);
    try {
      const summary = await summarizeText(originalText);
      setSummaryText(summary);
    } catch (err) {
      setSummaryText("Sorry, an error occurred while generating the summary.");
    } finally {
      setIsSummarizing(false);
    }
  };

  const resetApp = () => {
    setAppState('initial');
    setInputText('');
    setOriginalText('');
    setAnalyzedWords([]);
    setChatHistory([]);
    setError('');
  };
  
  const handleNavigateToDashboard = () => setView('dashboard');
  
  const handleNavigateHome = () => {
    if (view === 'main') {
        resetApp();
    } else {
        setView('main');
    }
  };

  const handleSelectHistoryItem = (text: string) => {
    setView('main');
    setAppState('initial');
    setInputText(text);
    setOriginalText('');
    setAnalyzedWords([]);
    setChatHistory([]);
    setError('');
  };

  const renderContent = () => {
    switch (appState) {
      case 'loading':
        return (
          <div className="flex flex-col items-center justify-center text-center min-h-[calc(100vh-80px)]">
            <div className="w-16 h-16 border-4 border-accentRed border-t-transparent rounded-full animate-spin"></div>
            <p className="mt-4 text-xl text-secondaryText/80">Analyzing your text...</p>
          </div>
        );
      case 'analyzed':
        return (
          <div className="container mx-auto p-4 md:p-8 grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
            <div className="lg:col-span-2">
              <AnalyzedText
                words={analyzedWords}
                onAddToFlashcards={handleAddFlashcard}
                onSummarize={handleSummarize}
              />
              <button onClick={resetApp} className="mt-6 bg-primaryRed text-white font-bold py-3 px-6 rounded-lg hover:bg-accentRed transition-colors shadow-lg shadow-primaryRed/20">
                Analyze New Text
              </button>
            </div>
            <div className="lg:col-span-1 space-y-8 sticky top-24">
              <AiChat messages={chatHistory} onSendMessage={handleSendMessage} isStreaming={isStreaming}/>
              <FlashcardDeck flashcards={flashcards} />
            </div>
          </div>
        );
      case 'error':
         return (
             <div className="flex flex-col items-center justify-center text-center min-h-[calc(100vh-80px)]">
                <p className="text-xl text-primaryRed mb-4">{error}</p>
                <button onClick={resetApp} className="bg-primaryRed text-white font-bold py-3 px-6 rounded-lg hover:bg-accentRed transition-colors">
                    Try Again
                </button>
            </div>
         );
      case 'initial':
      default:
        return (
          <div className="container mx-auto p-4 md:p-8 flex items-center justify-center min-h-[calc(100vh-80px)]">
            <div className="w-full max-w-3xl text-center">
              <BookOpenIcon className="mx-auto w-16 h-16 text-primaryRed mb-4"/>
              <h1 className="text-5xl font-extrabold text-secondaryText mb-2">Readly</h1>
              <p className="text-xl text-secondaryText/70 mb-8">Learn words, understand text, anywhere.</p>
              <div className="bg-cardBg rounded-2xl p-2 shadow-2xl">
                <textarea
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  placeholder="Paste your text here..."
                  className="w-full h-48 bg-cardBg text-secondaryText p-4 rounded-lg focus:outline-none focus:ring-2 focus:ring-primaryRed resize-none"
                />
              </div>
              <button
                onClick={handleAnalyzeText}
                className="mt-6 bg-primaryRed text-white font-bold text-lg py-4 px-12 rounded-xl hover:bg-accentRed transition-transform transform hover:scale-105 shadow-lg shadow-primaryRed/30"
              >
                Analyze Text
              </button>
            </div>
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-darkBg">
      <Header onNavigateHome={handleNavigateHome} onNavigateToDashboard={handleNavigateToDashboard} />
      <main>
        {view === 'dashboard' ? (
          <Dashboard
            history={history}
            flashcards={flashcards}
            onSelectHistoryItem={handleSelectHistoryItem}
          />
        ) : (
          renderContent()
        )}
      </main>
      {showSummaryModal && (
        <SummaryModal
          summary={summaryText}
          isLoading={isSummarizing}
          onClose={() => setShowSummaryModal(false)}
        />
      )}
    </div>
  );
};

export default App;