import { GoogleGenAI, Type, Chat, GenerateContentResponse } from "@google/genai";
import { ChatMessage, DifficultWord } from '../types';

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
let chatInstance: Chat | null = null;

export const analyzeTextForDifficultWords = async (text: string): Promise<DifficultWord[]> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: `Analyze the following text and identify words that might be difficult for an intermediate language learner. Return a JSON array of objects. Each object should have a 'word' key (the exact word from the text) and a 'definition' key (a simple, one-sentence definition or a translation into Arabic). Only include genuinely challenging words. Here is the text: "${text}"`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              word: {
                type: Type.STRING,
                description: "The difficult word found in the text."
              },
              definition: {
                type: Type.STRING,
                description: "A simple definition or translation of the word."
              }
            }
          }
        },
      },
    });

    const jsonString = response.text.trim();
    const result = JSON.parse(jsonString);
    return result as DifficultWord[];

  } catch (error) {
    console.error("Error analyzing text:", error);
    throw new Error("Failed to analyze text with Gemini API.");
  }
};

export const summarizeText = async (text: string): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: `Summarize the following text for a language learner. Keep the summary concise, simple, and easy to understand. Focus on the main points. Here is the text: "${text}"`,
    });
    return response.text;
  } catch (error) {
    console.error("Error summarizing text:", error);
    throw new Error("Failed to summarize text with Gemini API.");
  }
};


export const startChat = (originalText: string) => {
    chatInstance = ai.chats.create({
        model: 'gemini-2.5-flash',
        config: {
            systemInstruction: `You are a helpful language assistant named Readly. The user has provided the following text: "${originalText}". Answer their questions about this text concisely and clearly.`,
        },
    });
};

export async function* streamChatResponse(newMessage: string): AsyncGenerator<string> {
    if (!chatInstance) {
        throw new Error("Chat not initialized. Call startChat first.");
    }

    try {
        const result = await chatInstance.sendMessageStream({ message: newMessage });

        for await (const chunk of result) {
            yield chunk.text;
        }
    } catch (error) {
        console.error("Error streaming chat response:", error);
        throw new Error("Failed to get chat response from Gemini API.");
    }
}

export const generateVideo = async (prompt: string, onProgress: (message: string) => void): Promise<string> => {
  try {
    onProgress("Starting video generation...");
    let operation = await ai.models.generateVideos({
      model: 'veo-2.0-generate-001',
      prompt: prompt,
      config: {
        numberOfVideos: 1
      }
    });
    
    onProgress("Warming up the digital director...");
    let pollCount = 0;
    while (!operation.done) {
      if (pollCount % 2 === 0) onProgress("Rendering the first few frames...");
      else onProgress("Adding cinematic polish...");

      await new Promise(resolve => setTimeout(resolve, 10000));
      operation = await ai.operations.getVideosOperation({ operation: operation });
      pollCount++;
    }

    const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
    if (!downloadLink) {
        throw new Error("Video generation completed but no download link was found.");
    }

    // The downloadLink already includes a temporary token, so appending the API key is not always necessary,
    // but doing so ensures authentication if the token expires.
    const finalUrl = `${downloadLink}&key=${process.env.API_KEY}`;
    return finalUrl;

  } catch (error) {
    console.error("Error generating video:", error);
    throw new Error("Failed to generate video with Gemini API.");
  }
};